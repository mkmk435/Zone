# Supplementary Material S1 - Zone numerical evidence

This archive accompanies the revised manuscript. It provides numerical records,
derived tables, provenance, and calculation notes for inspecting the reported
results. It is not a frozen executable release of the engine and does not
contain payload binaries. The public Zone repository is linked in the paper.

File map:
- evidence/native.csv and llm_benign.csv: controlled functional benchmark.
- evidence/classifier.csv: annotated classification benchmark.
- evidence/wrap_full_corpus.csv: full-corpus wrapping outcomes.
- evidence/completed_20261114/: 816 LLM cells, grouped outcomes, scan membership
  and calculation notes. All cell outcomes remain, including failures.
- evidence/clarity_revision/: recovery outcomes by input and configuration.
- evidence/followup_20261115/: weighted overall update, per-input contributions,
  overall scan rates and accounting notes.
- evidence/editorial_20261115/: historical detection reanalysis and provenance.

The mean row of the overall working-rate table assigns each configuration 1/15
weight. Input rates within each configuration retain historical test-count
weights. These two aggregation levels must not be conflated.

Some calculation notes name raw source files maintained by the authors; those
files are documented through provenance but are not all included here. S1
supports inspection of numerical summaries, not regeneration of every binary
or rerunning every experiment. CHECKSUMS.json records the included file hashes.

Additional records: data_handling_comparison.csv provides the 19-input data comparison; version_manifests/ contains metadata and hashes only; SUMMARY.json files provide aggregate accounting; the .tex files retain detailed numerical tables and earlier pilot summaries moved out of the main manuscript.
